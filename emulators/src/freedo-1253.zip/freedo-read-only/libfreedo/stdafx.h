// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#ifndef AFX_STDAFX_H__MAZAFAKING_HEADER
#define AFX_STDAFX_H__MAZAFAKING_HEADER

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

//#include "astring.h"
#include "types.h"

extern bool __temporalfixes;
extern int HightResMode;
#define RESSCALE        HightResMode

#define DEBUG_CORE


#endif

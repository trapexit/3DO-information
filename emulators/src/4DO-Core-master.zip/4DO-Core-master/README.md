4DO-Core
========

OpenEmu Core plugin with 4DO/libfreedo to support 3DO emulation

mksquashfs ./opk 3doh.opk -all-root -noappend -no-exports -no-xattrs

// FreeDOFuncs.cpp
// compile with: /EHsc /LD

#include "FreeDOFuncs.h"
#include "libFreeDO/3doplay.h"
 


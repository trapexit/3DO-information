



int timerGettime();
void SE_timer_waitframerate(int millis);

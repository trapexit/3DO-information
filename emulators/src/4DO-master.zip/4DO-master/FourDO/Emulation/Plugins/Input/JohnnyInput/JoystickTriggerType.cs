﻿namespace FourDO.Emulation.Plugins.Input.JohnnyInput
{
	public enum JoystickTriggerType
	{
		Button,
		Axis,
		Pov
	}
}

﻿namespace FourDO.UI
{
	internal enum VoidAreaPattern
	{
		None,
		FourDO,
		Bumps,
		Metal
	}
}

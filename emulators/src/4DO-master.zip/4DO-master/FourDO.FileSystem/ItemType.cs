﻿namespace FourDO.FileSystem
{
	public enum ItemType
	{
		Directory,
		File
	}
}
